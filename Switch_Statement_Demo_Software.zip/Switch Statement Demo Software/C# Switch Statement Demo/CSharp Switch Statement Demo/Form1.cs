﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Switch_Statement_Demo
{
    public partial class Form1 : Form
    {
        private Boolean localMissionRadioBtnCheckedFlag;
        private Boolean localLaunchSystemCheckboxCheckedFlag;
        private Boolean localMissionMassListBoxCheckedFlag;

        public Boolean missionRadioBtnCheckedFlag
        {
            //  Class property - did the user click a mission radio button . . .

            get { return localMissionRadioBtnCheckedFlag; }
            set { localMissionRadioBtnCheckedFlag = value; }
        }

        public Boolean launchSystemCheckboxCheckedFlag
        {
            //  Class property - did the user check at least one launch system checkbox . . .

            get {return localLaunchSystemCheckboxCheckedFlag;}
            set {localLaunchSystemCheckboxCheckedFlag = value;}
        }

        public Boolean missionMassListBoxCheckedFlag
        {
            //  Class property - did the user pick a mission mass listbox value . . .

            get {return localMissionMassListBoxCheckedFlag; }
            set {localMissionMassListBoxCheckedFlag = value;}
        }

        private void RB_CheckedChanged(object sender, EventArgs e)
        {
            //  This event handler covers all the mission radio button CheckedChange
            //  events. The setup for this happens in the
            //
            //      From1.Designer.cs
            //
            //  file inside the InitializeComponent procedure. Note that RB6 does
            //  not get one of these event handlers because we want it completely
            //  "deactivated" . . .

            this.missionRadioBtnCheckedFlag = true;
        }

        private void CB_CheckedChanged(object sender, EventArgs e)
        {

            //  This event handler covers all the launch system checkbox CheckedChange events.
            //  Use OrElse to "short-circuit" the boolean test - as soon as the boolean sees
            //  one checkbox got checked, the test is true . . .
            
            if (
                    (this.CB1.Checked) ||
                    (this.CB2.Checked) ||
                    (this.CB3.Checked) ||
                    (this.CB4.Checked) ||
                    (this.CB5.Checked)
                )
            {
                this.launchSystemCheckboxCheckedFlag = true;
            }
            else
            {
                this.launchSystemCheckboxCheckedFlag = false;
            }
        }
        
        private void LB1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //  This event handler covers the mission mass SelectedIndexChanged event . . .

            this.missionMassListBoxCheckedFlag = true;
        }
        
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string missionPickedString = "User picked a mission";
            string launcherPickedString = "User picked at least one launcher";
            string missionMassPickedString = "User picked a mission mass";
            string missionDescTextString = "User typed a mission description";

            this.RTB2.Visible = true;

            //  Validate the user input . . .

            //      MNPF    <=> Mission picked flag
            //      LRPF    <=> Launcher picked flag
            //      MMPF    <=> Mission mass picked flag
            //      MTTF    <=> Mission text typed flag

            string MNPF;
            string LRPF;
            string MMPF;
            string MTTF;

            string assembledFlagFormString = "";
            string flagString = "";

            //  Formally convert the booleans to string values - 1's and / or 0's . . .

            MNPF = Convert.ToString(Convert.ToInt16(this.missionRadioBtnCheckedFlag));
            LRPF = Convert.ToString(Convert.ToInt16(this.launchSystemCheckboxCheckedFlag));
            MMPF = Convert.ToString(Convert.ToInt16(this.missionMassListBoxCheckedFlag));
            MTTF = Convert.ToString(Convert.ToInt16(this.RTB1.Text.Length > 0));

            //  Assemble the flagString value, and use it in the
            //
            //      Select Case
            //
            //  to drive assembly of the assembledFlagFormString
            //  value. Use
            //
            //      Convert.ToChar(13)
            //
            //  for the CRLF between the strings . . .

            flagString = MNPF + LRPF + MMPF + MTTF;

            switch (flagString)
            {
                case "0001": //     ( 1)    The user only typed a mission description . . .

                    assembledFlagFormString = missionDescTextString;
                    break;

                case "0010": //     ( 2)    The user only picked a mission mass . . .

                    assembledFlagFormString = missionMassPickedString;
                    break;

                case "0011": //     ( 3)    The user picked a mission mass and typed a mission description . . .

                    assembledFlagFormString = missionMassPickedString + Convert.ToChar(13) + missionDescTextString;
                    break;

                case "0100": //     ( 4)    The user only picked a launcher . . .

                    assembledFlagFormString = launcherPickedString;
                    break;

                case "0101": //     ( 5)    The user picked a launcher and typed a mission description . . .

                    assembledFlagFormString = launcherPickedString + Convert.ToChar(13) + missionDescTextString;
                    break;

                case "0110": //     ( 6)    The user picked a launcher and picked a mission mass . . .

                    assembledFlagFormString = launcherPickedString + Convert.ToChar(13) + missionMassPickedString;
                    break;

                case "0111": //     ( 7)    The user picked a launcher, a mission mass, and typed a mission description . . .

                    assembledFlagFormString = launcherPickedString + Convert.ToChar(13) + missionMassPickedString + Convert.ToChar(13) + missionDescTextString;
                    break;

                case "1000": //     ( 8)    The user only picked a mission . . .

                    assembledFlagFormString = missionPickedString;
                    break;

                case "1001": //     ( 9)    The user picked a mission and typed a mission description . . .

                    assembledFlagFormString = missionPickedString + Convert.ToChar(13) + missionDescTextString;
                    break;

                case "1010": //     (10)    The user picked a mission and a mission description . . .

                    assembledFlagFormString = missionPickedString + Convert.ToChar(13) + missionMassPickedString;
                    break;

                case "1011": //     (11)    The user picked a mission, a mission mass, and typed a mission description . . .

                    assembledFlagFormString = missionPickedString + Convert.ToChar(13) + missionMassPickedString + Convert.ToChar(13) + missionDescTextString;
                    break;

                case "1100": //     (12)    The user picked a mission and a launcher . . .

                    assembledFlagFormString = missionPickedString + Convert.ToChar(13) + launcherPickedString;
                    break;

                case "1101": //     (13)    The user picked a mission and a launcher, and typed a mission description . . .

                    assembledFlagFormString = missionPickedString + Convert.ToChar(13) + launcherPickedString + Convert.ToChar(13) + missionDescTextString;
                    break;

                case "1110": //     (14)    The user picked a mission, launcher, and a mission mass . . .

                    assembledFlagFormString = missionPickedString + Convert.ToChar(13) + launcherPickedString + Convert.ToChar(13) + missionMassPickedString;
                    break;

                case "1111": //     (15)    The user picked a mission, launcher, and a mission mass, and typed a mission description . . .

                    assembledFlagFormString = missionPickedString + Convert.ToChar(13) + launcherPickedString + Convert.ToChar(13) + missionMassPickedString + Convert.ToChar(13) + missionDescTextString;
                    break;

                case "0000": //     ( 0)    The user picked nothing . . . . . .

                    assembledFlagFormString = "The user picked nothing";
                    break;
            }            

            //  Place the assembled string in RTB2 for display . . .

            this.RTB2.Text = assembledFlagFormString;
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
        //  In form groupbox GB1, radio button RB6
        //  loads checked and has property "invisible"
        //  in the designer. This way, the form loads
        //  with no visibly checked radio buttons . . .

            this.resetControls();
            this.missionRadioBtnCheckedFlag = false;
            this.launchSystemCheckboxCheckedFlag = false;
            this.missionMassListBoxCheckedFlag = false;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            this.resetControls();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetControls()
        {
            CheckBox ChkBox = null;
            RadioButton RdBtn = null;

            this.RTB1.Text = "";

            //  Deselect any selected interplanetary mission radiobuttons . . .

            foreach (Object xObject in this.GB1.Controls)
                if (xObject is RadioButton)
                {
                    RdBtn = (RadioButton)xObject;
                    RdBtn.Checked = false;
                }

            //  Deselect any selected launch
            //  system checkboxes . . .

            foreach (Object xObject in this.GB2.Controls)
                if (xObject is CheckBox)
                {
                    ChkBox = (CheckBox)xObject;
                    ChkBox.Checked = false;
                }

            this.RTB2.Visible = false;
            this.RTB2.Text = "";

            //  Deselect the mission mass listbox . . .

            LB1.SelectedIndex = -1;

            //  Reset the flags . . .

            this.launchSystemCheckboxCheckedFlag = false;
            this.missionMassListBoxCheckedFlag = false;
            this.missionRadioBtnCheckedFlag = false;

        }
    }
}