﻿namespace CSharp_Switch_Statement_Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.RTB2 = new System.Windows.Forms.RichTextBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.RTB1 = new System.Windows.Forms.RichTextBox();
            this.LB1 = new System.Windows.Forms.ListBox();
            this.GB2 = new System.Windows.Forms.GroupBox();
            this.CB2 = new System.Windows.Forms.CheckBox();
            this.CB5 = new System.Windows.Forms.CheckBox();
            this.CB1 = new System.Windows.Forms.CheckBox();
            this.CB4 = new System.Windows.Forms.CheckBox();
            this.CB3 = new System.Windows.Forms.CheckBox();
            this.GB1 = new System.Windows.Forms.GroupBox();
            this.RB6 = new System.Windows.Forms.RadioButton();
            this.RB1 = new System.Windows.Forms.RadioButton();
            this.RB5 = new System.Windows.Forms.RadioButton();
            this.RB2 = new System.Windows.Forms.RadioButton();
            this.RB4 = new System.Windows.Forms.RadioButton();
            this.RB3 = new System.Windows.Forms.RadioButton();
            this.GB2.SuspendLayout();
            this.GB1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(631, 413);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(121, 45);
            this.btnClose.TabIndex = 31;
            this.btnClose.Text = "CLOSE";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // RTB2
            // 
            this.RTB2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RTB2.Location = new System.Drawing.Point(15, 288);
            this.RTB2.Name = "RTB2";
            this.RTB2.Size = new System.Drawing.Size(290, 277);
            this.RTB2.TabIndex = 30;
            this.RTB2.Text = "";
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(631, 342);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(121, 45);
            this.btnReset.TabIndex = 29;
            this.btnReset.Text = "RESET";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(631, 271);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(121, 45);
            this.btnSubmit.TabIndex = 28;
            this.btnSubmit.Text = "SUBMIT";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.SystemColors.Window;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.Label2.Location = new System.Drawing.Point(608, 73);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(144, 16);
            this.Label2.TabIndex = 27;
            this.Label2.Text = "Mission Description";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.SystemColors.Window;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.Label1.Location = new System.Drawing.Point(407, 73);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(142, 16);
            this.Label1.TabIndex = 26;
            this.Label1.Text = "Mission Mass In KG";
            // 
            // RTB1
            // 
            this.RTB1.Location = new System.Drawing.Point(564, 98);
            this.RTB1.Name = "RTB1";
            this.RTB1.Size = new System.Drawing.Size(230, 133);
            this.RTB1.TabIndex = 25;
            this.RTB1.Text = "";
            // 
            // LB1
            // 
            this.LB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.LB1.FormattingEnabled = true;
            this.LB1.ItemHeight = 16;
            this.LB1.Items.AddRange(new object[] {
            "             ANY",
            "          0 < 10",
            "      10 < 100",
            "     100 < 1 K",
            "    1 K < 10 K",
            "10 K < 100 K"});
            this.LB1.Location = new System.Drawing.Point(433, 98);
            this.LB1.Name = "LB1";
            this.LB1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LB1.Size = new System.Drawing.Size(92, 100);
            this.LB1.TabIndex = 24;
            this.LB1.SelectedIndexChanged += new System.EventHandler(this.LB1_SelectedIndexChanged);
            // 
            // GB2
            // 
            this.GB2.BackColor = System.Drawing.SystemColors.Window;
            this.GB2.Controls.Add(this.CB2);
            this.GB2.Controls.Add(this.CB5);
            this.GB2.Controls.Add(this.CB1);
            this.GB2.Controls.Add(this.CB4);
            this.GB2.Controls.Add(this.CB3);
            this.GB2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.GB2.Location = new System.Drawing.Point(204, 73);
            this.GB2.Name = "GB2";
            this.GB2.Size = new System.Drawing.Size(200, 158);
            this.GB2.TabIndex = 23;
            this.GB2.TabStop = false;
            this.GB2.Text = "Launch Systems";
            // 
            // CB1
            // 
            this.CB1.AutoSize = true;
            this.CB1.Location = new System.Drawing.Point(17, 25);
            this.CB1.Name = "CB1";
            this.CB1.Size = new System.Drawing.Size(76, 20);
            this.CB1.TabIndex = 6;
            this.CB1.Text = "Atlas V";
            this.CB1.UseVisualStyleBackColor = true;
            this.CB1.CheckedChanged += new System.EventHandler(this.CB_CheckedChanged);
            // 
            // CB2
            // 
            this.CB2.AutoSize = true;
            this.CB2.Location = new System.Drawing.Point(17, 49);
            this.CB2.Name = "CB2";
            this.CB2.Size = new System.Drawing.Size(80, 20);
            this.CB2.TabIndex = 7;
            this.CB2.Text = "Antares";
            this.CB2.UseVisualStyleBackColor = true;
            this.CB2.CheckedChanged += new System.EventHandler(this.CB_CheckedChanged);
            // 
            // CB3
            // 
            this.CB3.AutoSize = true;
            this.CB3.Location = new System.Drawing.Point(17, 73);
            this.CB3.Name = "CB3";
            this.CB3.Size = new System.Drawing.Size(72, 20);
            this.CB3.TabIndex = 8;
            this.CB3.Text = "Ariane";
            this.CB3.UseVisualStyleBackColor = true;
            this.CB3.CheckedChanged += new System.EventHandler(this.CB_CheckedChanged);
            // 
            // CB4
            // 
            this.CB4.AutoSize = true;
            this.CB4.Location = new System.Drawing.Point(17, 97);
            this.CB4.Name = "CB4";
            this.CB4.Size = new System.Drawing.Size(86, 20);
            this.CB4.TabIndex = 9;
            this.CB4.Text = "Falcon 1";
            this.CB4.UseVisualStyleBackColor = true;
            this.CB4.CheckedChanged += new System.EventHandler(this.CB_CheckedChanged);
            // 
            // CB5
            // 
            this.CB5.AutoSize = true;
            this.CB5.Location = new System.Drawing.Point(17, 121);
            this.CB5.Name = "CB5";
            this.CB5.Size = new System.Drawing.Size(69, 20);
            this.CB5.TabIndex = 10;
            this.CB5.Text = "Soyuz";
            this.CB5.UseVisualStyleBackColor = true;
            this.CB5.CheckedChanged += new System.EventHandler(this.CB_CheckedChanged);
            // 
            // GB1
            // 
            this.GB1.BackColor = System.Drawing.SystemColors.Window;
            this.GB1.Controls.Add(this.RB6);
            this.GB1.Controls.Add(this.RB1);
            this.GB1.Controls.Add(this.RB5);
            this.GB1.Controls.Add(this.RB2);
            this.GB1.Controls.Add(this.RB4);
            this.GB1.Controls.Add(this.RB3);
            this.GB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GB1.Location = new System.Drawing.Point(9, 73);
            this.GB1.Name = "GB1";
            this.GB1.Size = new System.Drawing.Size(186, 158);
            this.GB1.TabIndex = 22;
            this.GB1.TabStop = false;
            this.GB1.Text = "Interplanetary Missions";
            // 
            // RB6
            // 
            this.RB6.AutoSize = true;
            this.RB6.Checked = true;
            this.RB6.Location = new System.Drawing.Point(75, 71);
            this.RB6.Name = "RB6";
            this.RB6.Size = new System.Drawing.Size(105, 20);
            this.RB6.TabIndex = 5;
            this.RB6.TabStop = true;
            this.RB6.Text = "RBInvisible";
            this.RB6.UseVisualStyleBackColor = true;
            this.RB6.Visible = false;
            // 
            // RB1
            // 
            this.RB1.AutoSize = true;
            this.RB1.Location = new System.Drawing.Point(6, 25);
            this.RB1.Name = "RB1";
            this.RB1.Size = new System.Drawing.Size(77, 20);
            this.RB1.TabIndex = 0;
            this.RB1.Text = "Cassini";
            this.RB1.UseVisualStyleBackColor = true;
            this.RB1.CheckedChanged += new System.EventHandler(this.RB_CheckedChanged);
            // 
            // RB2
            // 
            this.RB2.AutoSize = true;
            this.RB2.Location = new System.Drawing.Point(6, 49);
            this.RB2.Name = "RB2";
            this.RB2.Size = new System.Drawing.Size(86, 20);
            this.RB2.TabIndex = 1;
            this.RB2.Text = "Curiosity";
            this.RB2.UseVisualStyleBackColor = true;
            this.RB2.CheckedChanged += new System.EventHandler(this.RB_CheckedChanged);
            // 
            // RB3
            // 
            this.RB3.AutoSize = true;
            this.RB3.Location = new System.Drawing.Point(6, 73);
            this.RB3.Name = "RB3";
            this.RB3.Size = new System.Drawing.Size(64, 20);
            this.RB3.TabIndex = 2;
            this.RB3.Text = "Dawn";
            this.RB3.UseVisualStyleBackColor = true;
            this.RB3.CheckedChanged += new System.EventHandler(this.RB_CheckedChanged);
            // 
            // RB4
            // 
            this.RB4.AutoSize = true;
            this.RB4.Location = new System.Drawing.Point(6, 97);
            this.RB4.Name = "RB4";
            this.RB4.Size = new System.Drawing.Size(128, 20);
            this.RB4.TabIndex = 3;
            this.RB4.Text = "Mars Observer";
            this.RB4.UseVisualStyleBackColor = true;
            this.RB4.CheckedChanged += new System.EventHandler(this.RB_CheckedChanged);
            // 
            // RB5
            // 
            this.RB5.AutoSize = true;
            this.RB5.Location = new System.Drawing.Point(6, 121);
            this.RB5.Name = "RB5";
            this.RB5.Size = new System.Drawing.Size(121, 20);
            this.RB5.TabIndex = 4;
            this.RB5.Text = "New Horizons";
            this.RB5.UseVisualStyleBackColor = true;
            this.RB5.CheckedChanged += new System.EventHandler(this.RB_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(806, 577);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.RTB2);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.RTB1);
            this.Controls.Add(this.LB1);
            this.Controls.Add(this.GB2);
            this.Controls.Add(this.GB1);
            this.Name = "Form1";
            this.Text = "Switch Statement Demo";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.GB2.ResumeLayout(false);
            this.GB2.PerformLayout();
            this.GB1.ResumeLayout(false);
            this.GB1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnClose;
        internal System.Windows.Forms.RichTextBox RTB2;
        internal System.Windows.Forms.Button btnReset;
        internal System.Windows.Forms.Button btnSubmit;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.RichTextBox RTB1;
        internal System.Windows.Forms.ListBox LB1;
        internal System.Windows.Forms.GroupBox GB2;
        internal System.Windows.Forms.CheckBox CB2;
        internal System.Windows.Forms.CheckBox CB5;
        internal System.Windows.Forms.CheckBox CB1;
        internal System.Windows.Forms.CheckBox CB4;
        internal System.Windows.Forms.CheckBox CB3;
        internal System.Windows.Forms.GroupBox GB1;
        internal System.Windows.Forms.RadioButton RB6;
        internal System.Windows.Forms.RadioButton RB1;
        internal System.Windows.Forms.RadioButton RB5;
        internal System.Windows.Forms.RadioButton RB2;
        internal System.Windows.Forms.RadioButton RB4;
        internal System.Windows.Forms.RadioButton RB3;
    }
}

