﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RB1 = New System.Windows.Forms.RadioButton()
        Me.RB2 = New System.Windows.Forms.RadioButton()
        Me.RB3 = New System.Windows.Forms.RadioButton()
        Me.RB4 = New System.Windows.Forms.RadioButton()
        Me.RB5 = New System.Windows.Forms.RadioButton()
        Me.GB1 = New System.Windows.Forms.GroupBox()
        Me.RB6 = New System.Windows.Forms.RadioButton()
        Me.CB1 = New System.Windows.Forms.CheckBox()
        Me.CB2 = New System.Windows.Forms.CheckBox()
        Me.CB3 = New System.Windows.Forms.CheckBox()
        Me.CB4 = New System.Windows.Forms.CheckBox()
        Me.CB5 = New System.Windows.Forms.CheckBox()
        Me.GB2 = New System.Windows.Forms.GroupBox()
        Me.LB1 = New System.Windows.Forms.ListBox()
        Me.RTB1 = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.RTB2 = New System.Windows.Forms.RichTextBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.GB1.SuspendLayout()
        Me.GB2.SuspendLayout()
        Me.SuspendLayout()
        '
        'RB1
        '
        Me.RB1.AutoSize = True
        Me.RB1.Location = New System.Drawing.Point(6, 25)
        Me.RB1.Name = "RB1"
        Me.RB1.Size = New System.Drawing.Size(77, 20)
        Me.RB1.TabIndex = 0
        Me.RB1.Text = "Cassini"
        Me.RB1.UseVisualStyleBackColor = True
        '
        'RB2
        '
        Me.RB2.AutoSize = True
        Me.RB2.Location = New System.Drawing.Point(6, 49)
        Me.RB2.Name = "RB2"
        Me.RB2.Size = New System.Drawing.Size(86, 20)
        Me.RB2.TabIndex = 1
        Me.RB2.Text = "Curiosity"
        Me.RB2.UseVisualStyleBackColor = True
        '
        'RB3
        '
        Me.RB3.AutoSize = True
        Me.RB3.Location = New System.Drawing.Point(6, 73)
        Me.RB3.Name = "RB3"
        Me.RB3.Size = New System.Drawing.Size(64, 20)
        Me.RB3.TabIndex = 2
        Me.RB3.Text = "Dawn"
        Me.RB3.UseVisualStyleBackColor = True
        '
        'RB4
        '
        Me.RB4.AutoSize = True
        Me.RB4.Location = New System.Drawing.Point(6, 97)
        Me.RB4.Name = "RB4"
        Me.RB4.Size = New System.Drawing.Size(128, 20)
        Me.RB4.TabIndex = 3
        Me.RB4.Text = "Mars Observer"
        Me.RB4.UseVisualStyleBackColor = True
        '
        'RB5
        '
        Me.RB5.AutoSize = True
        Me.RB5.Location = New System.Drawing.Point(6, 121)
        Me.RB5.Name = "RB5"
        Me.RB5.Size = New System.Drawing.Size(121, 20)
        Me.RB5.TabIndex = 4
        Me.RB5.Text = "New Horizons"
        Me.RB5.UseVisualStyleBackColor = True
        '
        'GB1
        '
        Me.GB1.BackColor = System.Drawing.SystemColors.Window
        Me.GB1.Controls.Add(Me.RB6)
        Me.GB1.Controls.Add(Me.RB1)
        Me.GB1.Controls.Add(Me.RB5)
        Me.GB1.Controls.Add(Me.RB2)
        Me.GB1.Controls.Add(Me.RB4)
        Me.GB1.Controls.Add(Me.RB3)
        Me.GB1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GB1.Location = New System.Drawing.Point(9, 73)
        Me.GB1.Name = "GB1"
        Me.GB1.Size = New System.Drawing.Size(186, 158)
        Me.GB1.TabIndex = 5
        Me.GB1.TabStop = False
        Me.GB1.Text = "Interplanetary Missions"
        '
        'RB6
        '
        Me.RB6.AutoSize = True
        Me.RB6.Checked = True
        Me.RB6.Location = New System.Drawing.Point(75, 71)
        Me.RB6.Name = "RB6"
        Me.RB6.Size = New System.Drawing.Size(105, 20)
        Me.RB6.TabIndex = 5
        Me.RB6.TabStop = True
        Me.RB6.Text = "RBInvisible"
        Me.RB6.UseVisualStyleBackColor = True
        Me.RB6.Visible = False
        '
        'CB1
        '
        Me.CB1.AutoSize = True
        Me.CB1.Location = New System.Drawing.Point(17, 25)
        Me.CB1.Name = "CB1"
        Me.CB1.Size = New System.Drawing.Size(76, 20)
        Me.CB1.TabIndex = 6
        Me.CB1.Text = "Atlas V"
        Me.CB1.UseVisualStyleBackColor = True
        '
        'CB2
        '
        Me.CB2.AutoSize = True
        Me.CB2.Location = New System.Drawing.Point(17, 49)
        Me.CB2.Name = "CB2"
        Me.CB2.Size = New System.Drawing.Size(80, 20)
        Me.CB2.TabIndex = 7
        Me.CB2.Text = "Antares"
        Me.CB2.UseVisualStyleBackColor = True
        '
        'CB3
        '
        Me.CB3.AutoSize = True
        Me.CB3.Location = New System.Drawing.Point(17, 73)
        Me.CB3.Name = "CB3"
        Me.CB3.Size = New System.Drawing.Size(72, 20)
        Me.CB3.TabIndex = 8
        Me.CB3.Text = "Ariane"
        Me.CB3.UseVisualStyleBackColor = True
        '
        'CB4
        '
        Me.CB4.AutoSize = True
        Me.CB4.Location = New System.Drawing.Point(17, 97)
        Me.CB4.Name = "CB4"
        Me.CB4.Size = New System.Drawing.Size(86, 20)
        Me.CB4.TabIndex = 9
        Me.CB4.Text = "Falcon 1"
        Me.CB4.UseVisualStyleBackColor = True
        '
        'CB5
        '
        Me.CB5.AutoSize = True
        Me.CB5.Location = New System.Drawing.Point(17, 121)
        Me.CB5.Name = "CB5"
        Me.CB5.Size = New System.Drawing.Size(69, 20)
        Me.CB5.TabIndex = 10
        Me.CB5.Text = "Soyuz"
        Me.CB5.UseVisualStyleBackColor = True
        '
        'GB2
        '
        Me.GB2.BackColor = System.Drawing.SystemColors.Window
        Me.GB2.Controls.Add(Me.CB2)
        Me.GB2.Controls.Add(Me.CB5)
        Me.GB2.Controls.Add(Me.CB1)
        Me.GB2.Controls.Add(Me.CB4)
        Me.GB2.Controls.Add(Me.CB3)
        Me.GB2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.GB2.Location = New System.Drawing.Point(201, 73)
        Me.GB2.Name = "GB2"
        Me.GB2.Size = New System.Drawing.Size(200, 158)
        Me.GB2.TabIndex = 11
        Me.GB2.TabStop = False
        Me.GB2.Text = "Launch Systems"
        '
        'LB1
        '
        Me.LB1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.LB1.FormattingEnabled = True
        Me.LB1.ItemHeight = 16
        Me.LB1.Items.AddRange(New Object() {"             ANY", "          0 < 10", "      10 < 100", "     100 < 1 K", "    1 K < 10 K", "10 K < 100 K"})
        Me.LB1.Location = New System.Drawing.Point(433, 98)
        Me.LB1.Name = "LB1"
        Me.LB1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LB1.Size = New System.Drawing.Size(92, 100)
        Me.LB1.TabIndex = 13
        '
        'RTB1
        '
        Me.RTB1.Location = New System.Drawing.Point(564, 98)
        Me.RTB1.Name = "RTB1"
        Me.RTB1.Size = New System.Drawing.Size(230, 133)
        Me.RTB1.TabIndex = 15
        Me.RTB1.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Window
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label1.Location = New System.Drawing.Point(407, 73)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(142, 16)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Mission Mass In KG"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Window
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label2.Location = New System.Drawing.Point(608, 73)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(144, 16)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Mission Description"
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(631, 271)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(121, 45)
        Me.btnSubmit.TabIndex = 18
        Me.btnSubmit.Text = "SUBMIT"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Location = New System.Drawing.Point(631, 342)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(121, 45)
        Me.btnReset.TabIndex = 19
        Me.btnReset.Text = "RESET"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'RTB2
        '
        Me.RTB2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RTB2.Location = New System.Drawing.Point(15, 288)
        Me.RTB2.Name = "RTB2"
        Me.RTB2.Size = New System.Drawing.Size(290, 277)
        Me.RTB2.TabIndex = 20
        Me.RTB2.Text = ""
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(631, 413)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(121, 45)
        Me.btnClose.TabIndex = 21
        Me.btnClose.Text = "CLOSE"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(806, 577)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.RTB2)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RTB1)
        Me.Controls.Add(Me.LB1)
        Me.Controls.Add(Me.GB2)
        Me.Controls.Add(Me.GB1)
        Me.Name = "Form1"
        Me.Text = "Switch Statement Demo"
        Me.GB1.ResumeLayout(False)
        Me.GB1.PerformLayout()
        Me.GB2.ResumeLayout(False)
        Me.GB2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RB1 As System.Windows.Forms.RadioButton
    Friend WithEvents RB2 As System.Windows.Forms.RadioButton
    Friend WithEvents RB3 As System.Windows.Forms.RadioButton
    Friend WithEvents RB4 As System.Windows.Forms.RadioButton
    Friend WithEvents RB5 As System.Windows.Forms.RadioButton
    Friend WithEvents GB1 As System.Windows.Forms.GroupBox
    Friend WithEvents CB1 As System.Windows.Forms.CheckBox
    Friend WithEvents CB2 As System.Windows.Forms.CheckBox
    Friend WithEvents CB3 As System.Windows.Forms.CheckBox
    Friend WithEvents CB4 As System.Windows.Forms.CheckBox
    Friend WithEvents CB5 As System.Windows.Forms.CheckBox
    Friend WithEvents GB2 As System.Windows.Forms.GroupBox
    Friend WithEvents LB1 As System.Windows.Forms.ListBox
    Friend WithEvents RTB1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents RTB2 As System.Windows.Forms.RichTextBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents RB6 As System.Windows.Forms.RadioButton

End Class
