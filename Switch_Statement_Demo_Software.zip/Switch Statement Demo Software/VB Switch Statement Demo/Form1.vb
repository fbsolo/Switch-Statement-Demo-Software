﻿Public Class Form1

    Private localMissionRadioBtnCheckedFlag As Boolean
    Private localLaunchSystemCheckboxCheckedFlag As Boolean
    Private localMissionMassListBoxCheckedFlag As Boolean

    Friend Property missionRadioBtnCheckedFlag As Boolean

        '   Class property - did the user click a mission radio button . . .

        Get
            Return localMissionRadioBtnCheckedFlag
        End Get

        Set(value As Boolean)
            localMissionRadioBtnCheckedFlag = value
        End Set

    End Property

    Friend Property launchSystemCheckboxCheckedFlag As Boolean

        '   Class property - did the user check at least one launch system checkbox . . .

        Get
            Return localLaunchSystemCheckboxCheckedFlag
        End Get

        Set(value As Boolean)
            localLaunchSystemCheckboxCheckedFlag = value
        End Set

    End Property

    Friend Property missionMassListBoxCheckedFlag As Boolean

        '   Class property - did the user pick a mission mass listbox value . . .

        Get
            Return localMissionMassListBoxCheckedFlag
        End Get

        Set(value As Boolean)
            localMissionMassListBoxCheckedFlag = value
        End Set

    End Property

    Private Sub RB_CheckedChanged(sender As Object, e As EventArgs) Handles RB1.CheckedChanged, _
                                                                             RB2.CheckedChanged, _
                                                                             RB3.CheckedChanged, _
                                                                             RB4.CheckedChanged, _
                                                                             RB5.CheckedChanged

        '   This event handler covers all the mission radio button CheckedChange events.
        '   Note that RB6 does not get one of these event handlers because we want it
        '   completely "deactivated" . . .

        Me.missionRadioBtnCheckedFlag = True

    End Sub

    Private Sub CB_CheckedChanged(sender As Object, e As EventArgs) Handles CB1.CheckedChanged, _
                                                                            CB2.CheckedChanged, _
                                                                            CB3.CheckedChanged, _
                                                                            CB4.CheckedChanged, _
                                                                            CB5.CheckedChanged

        '   This event handler covers all the launch system checkbox CheckedChange events.
        '   Use OrElse to "short-circuit" the boolean test - as soon as the boolean sees
        '   one checkbox got checked, the test is true . . .

        If (Me.CB1.Checked) OrElse _
            (Me.CB2.Checked) OrElse _
            (Me.CB3.Checked) OrElse _
            (Me.CB4.Checked) OrElse _
            (Me.CB5.Checked) Then
            Me.launchSystemCheckboxCheckedFlag = True
        Else
            Me.launchSystemCheckboxCheckedFlag = False
        End If
    End Sub

    Private Sub LB1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LB1.SelectedIndexChanged

        '   This event handler covers the mission mass SelectedIndexChanged event . . .

        Me.missionMassListBoxCheckedFlag = True

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        '   In form groupbox GB1, radio button RB6
        '   loads checked and has property "invisible"
        '   in the designer. This way, the form loads
        '   with no visibly checked radio buttons . . .

        Me.resetControls()
        Me.missionRadioBtnCheckedFlag = False
        Me.launchSystemCheckboxCheckedFlag = False
        Me.missionMassListBoxCheckedFlag = False

    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click

        Dim missionPickedString As String = "User picked a mission"
        Dim launcherPickedString As String = "User picked at least one launcher"
        Dim missionMassPickedString As String = "User picked a mission mass"
        Dim missionDescTextString As String = "User typed a mission description"

        Me.RTB2.Visible = True

        '   Validate the user input . . .

        '       MNPF    <=> Mission picked flag
        '       LRPF    <=> Launcher picked flag
        '       MMPF    <=> Mission mass picked flag
        '       MTTF    <=> Mission text typed flag

        Dim MNPF As String
        Dim LRPF As String
        Dim MMPF As String
        Dim MTTF As String

        Dim assembledFlagFormString = ""
        Dim flagString = ""

        '   Formally convert the booleans to string values - 1's and / or 0's . . .

        MNPF = Convert.ToString(Convert.ToInt16(Me.missionRadioBtnCheckedFlag))
        LRPF = Convert.ToString(Convert.ToInt16(Me.launchSystemCheckboxCheckedFlag))
        MMPF = Convert.ToString(Convert.ToInt16(Me.missionMassListBoxCheckedFlag))
        MTTF = Convert.ToString(Convert.ToInt16(Me.RTB1.Text.Length > 0))

        '   Assemble the flagString value, and use it in the
        '
        '       Select Case
        '
        '   to drive assembly of the assembledFlagFormString
        '   value. Use
        '
        '       Chr(13)
        '
        '   for the VBCRLF between the strings . . .

        flagString = MNPF + LRPF + MMPF + MTTF

        Select Case flagString

            Case "0001" '   ( 1)    The user only typed a mission description . . .

                assembledFlagFormString = missionDescTextString

            Case "0010" '   ( 2)    The user only picked a mission mass . . .

                assembledFlagFormString = missionMassPickedString

            Case "0011" '   ( 3)    The user picked a mission mass and typed a mission description . . .

                assembledFlagFormString = missionMassPickedString + Chr(13) + missionDescTextString

            Case "0100" '   ( 4)    The user only picked a launcher . . .

                assembledFlagFormString = launcherPickedString

            Case "0101" '   ( 5)    The user picked a launcher and typed a mission description . . .

                assembledFlagFormString = launcherPickedString + Chr(13) + missionDescTextString

            Case "0110" '   ( 6)    The user picked a launcher and  picked a mission mass . . .

                assembledFlagFormString = launcherPickedString + Chr(13) + missionMassPickedString

            Case "0111" '   ( 7)    The user picked a launcher, a mission mass, and typed a mission description . . .

                assembledFlagFormString = launcherPickedString + Chr(13) + missionMassPickedString + Chr(13) + missionDescTextString

            Case "1000" '   ( 8)    The user only picked a mission . . .

                assembledFlagFormString = missionPickedString

            Case "1001" '   ( 9)    The user picked a mission and typed a mission description . . .

                assembledFlagFormString = missionPickedString + Chr(13) + missionDescTextString

            Case "1010" '   (10)    The user picked a mission and a mission description . . .

                assembledFlagFormString = missionPickedString + Chr(13) + missionMassPickedString

            Case "1011" '   (11)    The user picked a mission, a mission mass, and typed a mission description . . .

                assembledFlagFormString = missionPickedString + Chr(13) + missionMassPickedString + Chr(13) + missionDescTextString

            Case "1100" '   (12)    The user picked a mission and a launcher . . .

                assembledFlagFormString = missionPickedString + Chr(13) + launcherPickedString

            Case "1101" '   (13)    The user picked a mission and a launcher, and typed a mission description . . .

                assembledFlagFormString = missionPickedString + Chr(13) + launcherPickedString + Chr(13) + missionDescTextString

            Case "1110" '   (14)    The user picked a mission, launcher, and a mission mass . . .

                assembledFlagFormString = missionPickedString + Chr(13) + launcherPickedString + Chr(13) + missionMassPickedString

            Case "1111" '   (15)    The user picked a mission, launcher, and a mission mass, and typed a mission description . . .

                assembledFlagFormString = missionPickedString + Chr(13) + launcherPickedString + Chr(13) + missionMassPickedString + Chr(13) + missionDescTextString

            Case "0000" '   ( 0)    The user picked nothing . . . . . .

                assembledFlagFormString = "The user picked nothing"

        End Select

        '   Place the assembled string in RTB2 for display . . .

        Me.RTB2.Text = assembledFlagFormString

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        Me.resetControls()

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Me.Close()

    End Sub

    Private Sub resetControls()

        Dim ChkBox As CheckBox = Nothing
        Dim RdBtn As RadioButton = Nothing

        Me.RTB1.Text = ""

        '   Deselect any selected interplanetary
        '   mission radiobuttons . . .

        For Each xObject As Object In Me.GB1.Controls
            If TypeOf xObject Is RadioButton Then
                RdBtn = xObject
                RdBtn.Checked = False
            End If
        Next

        '   Deselect any selected launch
        '   system checkboxes . . .

        For Each xObject As Object In Me.GB2.Controls
            If TypeOf xObject Is CheckBox Then
                ChkBox = xObject
                ChkBox.Checked = False
            End If
        Next

        Me.RTB2.Visible = False
        Me.RTB2.Text = ""

        '   Deselect the mission mass listbox . . .

        LB1.SelectedIndex = -1

        '   Reset the flags . . .

        Me.launchSystemCheckboxCheckedFlag = False
        Me.missionMassListBoxCheckedFlag = False
        Me.missionRadioBtnCheckedFlag = False

    End Sub
End Class